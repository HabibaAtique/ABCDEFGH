List_of_codes=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
List_of_Names=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
List_of_creditHours=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
List_of_sem=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

def isValidCourseCode():
	Uppercase_Characters=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
	Numeric_Characters=['0','1','2','3','4','5','6','7','8','9']
	if (x[0:1] in Uppercase_Characters) and (x[2:3:4] in Numeric_Characters):
		List_of_codes[y]=x
		return True
		print("your request has been submitted")
	return(x)

		
def isValidName():
	Uppercase_Characters=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
	if z[0] in Uppercase_Characters:
		List_of_Names[y]=z
		return True
	return(z)
def isValidCreditHours():
	Num=[1,2,3]
	if (p in Num):
		List_of_creditHours[y]=p
		return True
	return(p)
		
def isValidsemesters():
	available_sem=[0,1,2,3,4,5,6,7,8]
	if (k in available_sem):
		List_of_sem[y]=k
		return True
	return(k)
def Add_Course():
	add_course=[isValidCourseCode(),isValidName(),isValidCreditHours(),isValidsemesters()]
	t=[x,z,p,k]
	print("your course details: ",t)
	return()
def Update_Course():
	u=0
	while u<y:
		print(u+1,List_of_codes[u],List_of_Names[u],List_of_creditHours[u],List_of_sem[u])
		u+=1
	d=int(input("course to be changed: "))
	List_of_codes[d-1]=0
	List_of_Names[d-1]=0
	List_of_creditHours[d-1]=0
	List_of_sem[d-1]=0
	Uppercase_Characters=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
	Numeric_Characters=[0,1,2,3,4,5,6,7,8,9]
	n=str(input("enter code: "))
	if (n[0:1] in Uppercase_Characters) and (n[2:3:4] in Numeric_Characters):
		List_of_codes[d-1]=n
		f=str(input("enter name"))
		List_of_Names[d-1]=f
	else:
		print("invalid code: ")
		n=str(input("enter code: "))
		if (n[0:1] in Uppercase_Characters) and (n[2:3:4] in Numeric_Characters):
			List_of_codes[d-1]=n
			f=str(input("enter name"))
			List_of_Names[d-1]=f
	f=str(input("enter name"))
	if f[0] in Uppercase_Characters:
		List_of_Names[d-1]=f
	else:
		print("invalid name")
		f=str(input("enter name"))
		if f[0] in Uppercase_Characters:
			List_of_Names[d-1]=f
	Num=[1,2,3]
	v=int(input("enter credit hours"))
	if (v in Num):
		List_of_creditHours[d-1]=v
	else:
		print("invalid credit hours")
		v=int(input("enter credit hours"))
		if (v in Num):
			List_of_creditHours[d-1]=v
	available_sem=[0,1,2,3,4,5,6,7,8]
	c=int(input("enter semester"))
	if  (c in available_sem):
		List_of_sem[d-1]=c
	else:
		print("invalid semesters")
		c=int(input("enter semester"))
		if  (c in available_sem):
			List_of_sem[d-1]=c
	print("your course "+str(d)+" has been updated to : ",List_of_codes[d-1],List_of_Names[d-1],List_of_creditHours[d-1],List_of_sem[d-1])
		
def Delete_Course():
	u=0
	while u<y:
		print(u+1,List_of_codes[u],List_of_Names[u],List_of_creditHours[u],List_of_sem[u])
		u+=1
	d=int(input("course to be deleted: "))
	List_of_codes[d-1]=0
	List_of_Names[d-1]=0
	List_of_creditHours[d-1]=0
	List_of_sem[d-1]=0
	List_of_codes[d-1] = List_of_codes[u-1]
	List_of_Names[d-1]= List_of_Names[u-1]
	List_of_creditHours[d-1] = List_of_creditHours[u-1]
	List_of_sem[d-1] = List_of_sem[u-1]
	List_of_codes[u-1]=0
	List_of_Names[u-1]=0
	List_of_creditHours[u-1]=0
	List_of_sem[u-1]=0
def View_Courses():
	s=0
	print("COurse_CODE  ","Course_NAME  ","CREDIT_HOURS  ","SEMESTER")
	while s<y:
		print(str(List_of_codes[s])+"           "+str(List_of_Names[s])+"          ",str(List_of_creditHours[s])+"         ",str(List_of_sem[s]))
		s+=1
def View_Courses_of_a_semester():
	s=int(input("choose semester: "))
	print("COURSE_CODE ","COURSE_NAME ","CREDIT_HOURS ")
	e=0
	while e<y:
		if s==List_of_sem[e]:
			print((List_of_codes[e])+"        "+(List_of_Names[e])+"             "+str(List_of_creditHours[e]))
		e+=1
		
print("***Welcome to the University learning management system***")
y=0
while -1: 
	print("1 ","add corse")
	print("2 ","update course")
	print("3 ","Delete course")
	print("4 ","View all courses")
	print("5 ","View courses of a semester")
	print("6 ","Exit program")	
	g=int(input("Choose the option: "))
	if g==1:
		x=str(input("course code: "))
		z=str(input("subject name: "))
		p=int(input("cretdit hours : "))
		k=int(input("semester: "))
		if ((isValidCourseCode() is True) and (isValidName() is True) and (isValidCreditHours() is True) and (isValidsemesters() is True)):
			Add_Course()
		else:
			print("Invalid Details")
			y-=1
			
		y+=1
	if g==2:
		Update_Course()
	if g==3:
		Delete_Course()
		y-=1
	if g==4:
		View_Courses()
	if g==5:
		View_Courses_of_a_semester()
	if g==6:
		quit()
	print("_____________________________________________________________________________________________________________________________________________________________________")